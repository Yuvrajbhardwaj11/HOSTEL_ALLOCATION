# 🏠 HostelOS — Hostel Allocation Management System

A full-stack MERN application for automated, priority-based hostel room allocation.

---

## 🚀 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, React Router v6, Recharts, Lucide Icons |
| Backend | Node.js, Express.js |
| Database | MongoDB (Atlas) |
| Auth | JWT (JSON Web Tokens) |
| Deployment | Vercel (Frontend + Serverless API) |

---

## 📁 Project Structure

```
hostel-alloc/
├── api/                    # Express backend
│   ├── models/
│   │   ├── User.js         # Admin/Warden users
│   │   ├── Student.js      # Student profiles + priority engine
│   │   ├── Room.js         # Room inventory
│   │   └── Allocation.js   # Allocation records
│   ├── routes/
│   │   ├── auth.js         # Login / Register / Me
│   │   ├── students.js     # CRUD + ranked list
│   │   ├── rooms.js        # CRUD + bulk create
│   │   ├── allocations.js  # Manual + Auto allocation
│   │   └── dashboard.js    # Stats & analytics
│   ├── middleware/
│   │   └── auth.js         # JWT protect + adminOnly
│   └── server.js           # Express app entry
├── client/                 # React frontend
│   ├── src/
│   │   ├── context/AuthContext.js
│   │   ├── utils/api.js
│   │   ├── components/Layout.js
│   │   └── pages/
│   │       ├── Login.js
│   │       ├── Dashboard.js
│   │       ├── Students.js
│   │       ├── Rooms.js
│   │       └── Allocations.js
│   └── public/index.html
├── vercel.json             # Vercel deployment config
├── .env.example
└── package.json
```

---

## ⚙️ Local Setup

### 1. Clone & Install

```bash
git clone <your-repo>
cd hostel-alloc
npm run install-all
```

### 2. Environment Variables

Copy `.env.example` to `.env` and fill in:

```env
MONGODB_URI=mongodb+srv://<user>:<pass>@cluster.mongodb.net/hostel_alloc
JWT_SECRET=your_super_secret_key
PORT=5000
```

### 3. Run Development

```bash
npm run dev
# Backend: http://localhost:5000
# Frontend: http://localhost:3000
```

---

## 🌐 Vercel Deployment

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/hostel-alloc.git
git push -u origin main
```

### Step 2 — Import to Vercel

1. Go to [vercel.com](https://vercel.com) → **New Project**
2. Import your GitHub repository
3. Framework: **Other** (not CRA — the vercel.json handles it)
4. Root Directory: leave as `/`

### Step 3 — Environment Variables in Vercel

In Vercel dashboard → Settings → Environment Variables, add:

| Key | Value |
|-----|-------|
| `MONGODB_URI` | Your MongoDB Atlas connection string |
| `JWT_SECRET` | A long random secret string |
| `NODE_ENV` | `production` |
| `REACT_APP_API_URL` | Leave empty (uses relative URLs) |

### Step 4 — Deploy 🎉

Click **Deploy**. Vercel auto-builds frontend and deploys backend as serverless functions.

---

## 🧠 Priority Algorithm

Students are ranked before allocation using a weighted score:

```
Priority Score = 
  (CGPA × 5)                     → max 50 pts
  + Disability bonus              → +30 pts
  + Low income (<2L)              → +20 pts
  + Mid income (2L–5L)            → +10 pts
  + Year seniority (6 - year) × 3 → max 15 pts
  + Outstation student            → +15 pts
```

Auto-allocation then:
1. Sorts all `Pending` students by priority score (desc)
2. Matches each student to the best available room considering:
   - Gender constraints
   - Accessibility needs
   - Room type preferences
   - Even distribution across rooms (fill lowest-occupancy first)
3. Marks unmatched students as `Waitlisted`

---

## 🔐 API Endpoints

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/register` | Register admin |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Current user |

### Students
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/students` | List (paginated, filterable) |
| POST | `/api/students` | Add student |
| PUT | `/api/students/:id` | Update student |
| DELETE | `/api/students/:id` | Delete student |
| GET | `/api/students/ranked/list` | Priority-ranked pending list |

### Rooms
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/rooms` | List (filterable) |
| POST | `/api/rooms` | Create room |
| POST | `/api/rooms/bulk` | Bulk create rooms |
| PUT | `/api/rooms/:id` | Update room |
| DELETE | `/api/rooms/:id` | Delete room |

### Allocations
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/allocations` | List active allocations |
| POST | `/api/allocations` | Manual allocation |
| POST | `/api/allocations/auto-allocate` | Run auto-allocation |
| DELETE | `/api/allocations/:id` | Vacate allocation |

### Dashboard
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/dashboard/stats` | Full statistics |

---

## ✅ Features

- 🔐 JWT Authentication (Admin / Warden roles)
- 👥 Student CRUD with priority score computation
- 🏠 Room CRUD with amenity tracking and occupancy
- ⚡ Auto-allocation with priority-based algorithm
- 🖐 Manual allocation with gender/accessibility validation
- 📊 Dashboard with live charts (bar, pie, horizontal bar)
- 🔍 Search & filter across all modules
- 📄 Pagination for large datasets
- 🌙 Dark theme UI
- 📱 Responsive layout

---

## 📦 Seed Data (Optional)

To quickly seed test data, use the Bulk Create endpoint:

```bash
POST /api/rooms/bulk
{
  "rooms": [
    { "roomNumber": "A-101", "block": "A", "floor": 1, "type": "Double", "capacity": 2, "gender": "Male", "amenities": ["WiFi", "Fan"], "monthlyRent": 3000 },
    { "roomNumber": "A-102", "block": "A", "floor": 1, "type": "Single", "capacity": 1, "gender": "Male", "amenities": ["AC", "WiFi"], "monthlyRent": 5000 },
    { "roomNumber": "B-101", "block": "B", "floor": 1, "type": "Triple", "capacity": 3, "gender": "Female", "amenities": ["Fan", "WiFi"], "monthlyRent": 2000 }
  ]
}
```
